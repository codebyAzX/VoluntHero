package com.example.volunthero;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class LanguageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        ImageButton btnArm = findViewById(R.id.btn_arm);
        ImageButton btnRu = findViewById(R.id.btn_ru);
        ImageButton btnEn = findViewById(R.id.btn_en);

        setupLanguageButton(btnArm, "hy");
        setupLanguageButton(btnRu, "ru");
        setupLanguageButton(btnEn, "en");
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupLanguageButton(View view, String langCode) {
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(100).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).withEndAction(() -> {
                        updateLanguage(langCode);
                    }).start();
                    break;
            }
            return true;
        });
    }

    @SuppressWarnings("deprecation")
    private void updateLanguage(String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.setLocale(locale);
        res.updateConfiguration(conf, dm);

        // перезапуск экрана логин
        Intent intent = new Intent(LanguageActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}