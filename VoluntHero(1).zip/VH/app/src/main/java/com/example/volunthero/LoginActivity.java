package com.example.volunthero;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.text.TextPaint;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private TextView tvLogo, tvGoToRegister, tvForgotPassword;
    private Button btnContinue;
    private TextInputEditText etEmail, etPassword; // Теперь обе переменные на месте

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1. Инициализация всех View
        tvLogo = findViewById(R.id.tvLogo);
        tvGoToRegister = findViewById(R.id.tvGoToRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        btnContinue = findViewById(R.id.btnContinue);

        // Привязываем к правильным ID из XML
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        applyGradientToLogo();

        // 2. Логика восстановления пароля
        tvForgotPassword.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();

            if (email.isEmpty()) {
                etEmail.setError("Введите email в поле логина");
                return;
            }

            FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(LoginActivity.this, "Письмо отправлено!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LoginActivity.this, "Ошибка: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        tvGoToRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        btnContinue.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            } else {
                // Здесь будет Firebase Sign In
                Toast.makeText(this, "Вход для " + email, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void applyGradientToLogo() {
        tvLogo.post(() -> {
            TextPaint paint = tvLogo.getPaint();
            float width = paint.measureText(tvLogo.getText().toString());

            Shader textShader = new LinearGradient(0, 0, width, 0,
                    new int[]{
                            Color.parseColor("#7E57C2"), // Фиолетовый
                            Color.parseColor("#38FFD7")  // Бирюзовый
                    }, null, Shader.TileMode.CLAMP);

            paint.setShader(textShader);
            tvLogo.invalidate();
        });
    }
}